#ifndef GAMEWIDGET_H
#define GAMEWIDGET_H
#include <QTimer>
#include <QWidget>
#include <QKeyEvent>
#include <QString>
#include <string>

class GameWidget : public QWidget
{
    Q_OBJECT
public:
    int xKor,yKor;  // Koordinaten
    int rectHeight; // Grosses Spielfeld(Quadrat)
    int input;
    int spiel = 0; // am Anfang beim Öffnen in GameofLife modus
    int zellen = 0; //welche zellen gesetzt werden

    QTimer *timer = new QTimer(this); //erstellt
    QTimer *timer2 = new QTimer(this); //erstellt für Snake
    QTimer *timer3 = new QTimer(this); //erstellt für HunterandHunted



    explicit GameWidget(QWidget *parent = nullptr);

    void paintEvent(QPaintEvent *event);
    void mousePressEvent(QMouseEvent *e);
    void mouseMoveEvent(QMouseEvent *e);
    void setTimerIntervall(int arg1);
    void startGame();
    void stopGame();
    void clearBoard();
    void UniversumGroesse(int a);
    void Savefield();
    void Loadfield();
    void preparefieldsnake(std::string a);
    void Zellen(std::string a);
    void Lebenszeit(int a);

signals:

public slots:
    void nextGeneration();
    void Bewegung(int a = 0);
    void jagen();
};

#endif // GAMEWIDGET_H
