#include "cabase.h"
#include <iostream>
using namespace std;

HunterandHunted::HunterandHunted(int a, int b){
    Nx = a;
    Ny = b;
    altesfeld = new int* [a];
    neuesfeld = new int* [a];
    for (int i = 0; i < a; i++){
        altesfeld [i] = new int [b];
        neuesfeld [i] = new int [b];}
    for(int i = 0; i < a; i++)
    {for (int j = 0; j < b; j++)
        {altesfeld [i] [j] = 0;
         neuesfeld [i] [j] = 0;
        }
    }
}

void HunterandHunted::CellEvolutionDirection(int a, int b)
{
    if (altesfeld[a][b] >= 2)
    {
        if (altesfeld[a-1] [b] <= -1)
        {
            CellEvolutionMove(a,b,1); //links
        }
        else if (altesfeld[a] [b-1] <= -1) {
            CellEvolutionMove(a,b,3); //oben

        }
        else if (altesfeld[a + 1] [b] <= -1) {
            CellEvolutionMove(a,b,2); //rechts

        }
        else if (altesfeld[a] [b+1] <= -1) {
            CellEvolutionMove(a,b,0); //unten
        }
        else
        {
            CellEvolutionMove(a,b,rand()%4);
        }
    }

   else if (altesfeld[a][b] <= -1 and altesfeld[a-1][b] < 2 and altesfeld[a+1][b] < 2 and altesfeld[a][b-1] < 2 and altesfeld[a][b+1] < 2)
   {
       if (altesfeld[a-1] [b] == 1)
       {
           CellEvolutionMove(a,b,1);
       }
       else if (altesfeld[a] [b-1] == 1) {
           CellEvolutionMove(a,b,3);

       }
       else if (altesfeld[a + 1] [b] == 1) {
           CellEvolutionMove(a,b,2);

       }
       else if (altesfeld[a] [b+1] == 1) {
           CellEvolutionMove(a,b,0);
       }
       else
       {
           CellEvolutionMove(a,b,rand()%4);
       }
   }
   else
   {
       CellEvolutionMove(a,b,4);
   }
}

void HunterandHunted::setNx(int a)
{
    delete altesfeld;
    delete neuesfeld;
    Nx = a;
    Ny = a;
    altesfeld= new int* [a];
    neuesfeld = new int* [a];
    for (int i = 0; i < a; i++){
        altesfeld [i] = new int [a];
        neuesfeld [i] = new int [a];}
    for(int i = 0; i < a; i++)
    {for (int j = 0; j < a; j++)
        {altesfeld [i] [j] = 0;
         neuesfeld [i] [j] = 0;
        }

    }
}

HunterandHunted::getNx()
{
    return Nx;
}

void HunterandHunted::CellEvolutionMove(int a, int b, int direction)
{
    switch (direction) {
    case 0:
        if (altesfeld[a][b] < 0 and b+1 < getNx())
        {
            if (altesfeld[a] [b+1] == 1 and neuesfeld[a][b+1] == 0)
            {
                neuesfeld[a] [b+1] = -1 * lebensspanne;
            }
            else if(neuesfeld[a] [b+1] < 0)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a] [b+1] = altesfeld[a] [b] + 1;
            }
        }
        else if (altesfeld[a][b] > 1 and b+1 < getNx())
        {
            if (altesfeld[a] [b+1] < 0 and neuesfeld[a][b+1] < 2)
            {
                neuesfeld[a] [b+1] = 2 * lebensspanne;
            }
            else if(neuesfeld[a] [b+1] >= 1)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a] [b+1] = altesfeld[a] [b] - 2;
            }
        }
        else
        {
            CellEvolutionMove(a,b,4);
        }
        break;
    case 1:
        if (altesfeld[a][b] < 0 and a-1 > -1)
        {
            if (altesfeld[a-1] [b] == 1 and neuesfeld[a-1][b] == 0)
            {
                neuesfeld[a-1] [b] = -1 * lebensspanne;
            }
            else if(neuesfeld[a-1] [b] < 0)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a-1] [b] = altesfeld[a] [b] + 1;
            }
        }
        else if (altesfeld[a][b] > 1 and a-1 > -1)
        {
            if (altesfeld[a-1] [b] < 0 and neuesfeld[a-1][b] < 2)
            {
                neuesfeld[a-1] [b] = 2 * lebensspanne;
            }
            else if(neuesfeld[a-1] [b] >= 1)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a-1] [b] = altesfeld[a] [b] - 2;
            }
        }
        else
        {
            CellEvolutionMove(a,b,4);
        }
        break;
    case 2:
        if (altesfeld[a][b] < 0 and a+1 < getNx())
        {
            if (altesfeld[a+1] [b] == 1 and neuesfeld[a+1][b] == 0)
            {
                neuesfeld[a+1] [b] = -1 * lebensspanne;
            }
            else if(neuesfeld[a+1] [b] < 0)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a+1] [b] = altesfeld[a] [b] + 1;
            }
        }
        else if (altesfeld[a][b] > 1 and a+1 < getNx())
        {
            if (altesfeld[a+1] [b] < 0 and neuesfeld[a+1][b] < 2)
            {
                neuesfeld[a+1] [b] = 2 * lebensspanne;
            }
            else if(neuesfeld[a+1] [b] >= 1)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a+1] [b] = altesfeld[a] [b] -2 ;
            }
        }
        else
        {
            CellEvolutionMove(a,b,4);
        }
        break;
    case 3:
        if (altesfeld[a][b] < 0 and b-1 > -1)
        {
            if (altesfeld[a] [b-1] == 1 and neuesfeld[a][b-1] == 0)
            {
                neuesfeld[a] [b-1] = -1 * lebensspanne;
            }
            else if(neuesfeld[a] [b-1] < 0)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a] [b-1] = altesfeld[a] [b] + 1;
            }
        }
        else if (altesfeld[a][b] > 1 and b-1 > -1)
        {
            if (altesfeld[a] [b-1] < 0 and neuesfeld[a][b-1] < 2)
            {
                neuesfeld[a] [b-1] = 2 * lebensspanne;
            }
            else if(neuesfeld[a] [b-1] >= 1)
            {
               CellEvolutionMove(a,b,4);
            }
            else
            {
                neuesfeld[a] [b-1] = altesfeld[a] [b] - 2;
            }
        }
        else
        {
            CellEvolutionMove(a,b,4);
        }
        break;
    case 4:
        if(altesfeld[a][b] == 1)
        {
            if (neuesfeld[a][b] == 0)
            {
                neuesfeld[a][b] = 1;
            }
        }
        if(altesfeld[a][b] > 2)
        {
            if (neuesfeld[a][b] == 0)
            {
                neuesfeld[a][b] = altesfeld[a][b] - 2;
            }
            else
            {
                if(neuesfeld[a-1][b] == 0)
                {neuesfeld[a-1][b] = altesfeld[a][b] - 2;}
                else if(neuesfeld[a+1][b] == 0)
                {neuesfeld[a+1][b] = altesfeld[a][b] - 2;}
                else if(neuesfeld[a][b+1] == 0)
                {neuesfeld[a][b+1] = altesfeld[a][b] - 2;}
                else if(neuesfeld[a][b-1] == 0)
                {neuesfeld[a][b-1] = altesfeld[a][b] - 2;}

            }
        }
        if(altesfeld[a][b] < 0)
        {
            if (neuesfeld[a][b] == 0)
            {
                neuesfeld[a][b] = altesfeld[a][b] + 1;
            }
            else
            {
                if(neuesfeld[a-1][b] == 0)
                {neuesfeld[a-1][b] = altesfeld[a][b] + 1;}
                else if(neuesfeld[a+1][b] == 0)
                    neuesfeld[a+1][b] = altesfeld[a][b] + 1;
                else if(neuesfeld[a][b+1] == 0)
                    neuesfeld[a][b+1] = altesfeld[a][b] + 1;
                else if(neuesfeld[a][b-1] == 0)
                    neuesfeld[a][b-1] = altesfeld[a][b] + 1;

            }
        }

        break;
    default:
        break;
    }

}

void HunterandHunted::setFood(int a, int b)
{
    altesfeld[a][b] = 1;
}

void HunterandHunted::setHunter(int a, int b)
{
    altesfeld[a][b] = 2 * lebensspanne;
}

void HunterandHunted::setHunted(int a, int b)
{
    altesfeld[a][b] = -1 * lebensspanne;
}

void HunterandHunted::WorldEvolutionLifePredator()
{
    for(int i = 0; i < getNx(); i++)
    {
        for(int j = 0; j < getNx(); j++)
        {
            CellEvolutionDirection(i,j);
        }
    }
    for(int i = 0; i < getNx(); i++)
    {
        for(int j = 0; j < getNx(); j++)
        {
            altesfeld[i][j] = neuesfeld[i][j];
            neuesfeld[i][j] = 0;
        }
    }
}

HunterandHunted::getZelle(int a, int b)
{
    return altesfeld[a][b];
}

void HunterandHunted::setLebensspanne(int a)
{
    lebensspanne = a;
}
