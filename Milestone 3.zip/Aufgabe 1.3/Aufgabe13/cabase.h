#ifndef CABASE_H
#define CABASE_H

class CAbase
{

public:

    int Nx;
    int Ny;
    int** altesarray;
    int** neuesarray;
    int input;

    CAbase();
    CAbase(int a, int b) {
        Nx = a;
        Ny = b;
        altesarray = new int* [a];
        neuesarray = new int* [a];
        for (int i = 0; i < a; i++){
            altesarray [i] = new int [b];
            neuesarray [i] = new int [b];}
        for(int i = 0; i < a; i++)
        {for (int j = 0; j < b; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }
    }

    int getNx() {
        return Nx;}

    int getNy() {
        return Ny;}

    void setNx(int a) {
        delete altesarray;
        delete neuesarray;
        Nx = a;
        altesarray = new int* [Nx];
        neuesarray = new int* [Nx];
        for (int i = 0; i < Nx; i++){
            altesarray [i] = new int [Ny];
            neuesarray [i] = new int [Ny];}
        for(int i = 0; i < Nx; i++)
        {for (int j = 0; j < Ny; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }

    }

    void setNy(int a) {
        for (int j = 0; j < Nx; j++)
        {
            delete altesarray [j];
            delete neuesarray [j];}
        Ny = a;
        for (int i = 0; i < Nx; i++){
            altesarray [i] = new int [Ny];
            neuesarray [i] = new int [Ny];}
        for(int i = 0; i < Nx; i++)
        {for (int j = 0; j < Ny; j++)
            {altesarray [i] [j] = 0;
             neuesarray [i] [j] = 0;
            }
        }


    }

    void setzelle(int a, int b){
        altesarray [a] [b] = 1;
    }

    int getzelle(int a, int b) {
        return altesarray [a] [b];
    }

    void spieldeslebens(int a, int b){
        int count = 0;
        for(int i = a + Nx - 1; i <= a + Nx + 1; i++){
            for(int j = b + Ny - 1; j <= b + Ny + 1; j++){
                if( altesarray [i % Nx] [j % Ny] == 1 and (a + Nx != i or b + Ny != j) ){
                    count = count + 1;}}
        }

        if (altesarray [a % Nx] [b % Ny] == 1)
        {

            if (count < 2 or count > 3)
                neuesarray [a % Nx] [b % Ny] = 0;
            if (count > 1 and count < 4)
                neuesarray [a % Nx] [b % Ny] = 1;}

        if (count == 3 and altesarray [a % Nx] [b % Ny] == 0)
            neuesarray [a % Nx] [b % Ny] = 1;
    }

    void spieldeslebensmitnelementN() {
        for(int i = 0; i < Nx; i++)
            for (int j = 0; j < Ny; j++)
                spieldeslebens(i,j);
        for(int a = 0; a < Nx; a++)
            for (int b = 0; b < Ny; b++)
                altesarray [a] [b] = neuesarray [a] [b];
    }




    ~CAbase() {
        delete altesarray;
        delete neuesarray;}

};

class SnakeFeld //Klasse Snake
{
    int bewegungErlaubt = 1;
    int lastInput;
    int Nx;
    int Ny;
    int** altesfeld;
    int Laenge;
    int kopfzellex;
    int kopfzelley;
public: // Deklaration der Methoden
    SnakeFeld(int a, int b);
    int returnNx();
    int returnNy();
    int returnLaenge();
    void setZelle(int a, int b);
    void Bewegung(int a);
    void updateFeld();
    int getZelle(int a, int b);
    void resetspiel();
    void essen();
    void richtungersetzen();

    ~SnakeFeld();
};

class HunterandHunted
{
    int** altesfeld;
    int** neuesfeld;
    int lebensspanne = 10;
    int Nx;
    int Ny;

public:
    HunterandHunted(int a, int b);
    int getNx();
    int getZelle(int a, int b);
    void setNx(int a);
    void setHunter(int a, int b);
    void setHunted(int a, int b);
    void setFood(int a, int b);
    void CellEvolutionDirection(int a, int b);
    void CellEvolutionMove(int a, int b, int direction);
    void WorldEvolutionLifePredator();
    void setLebensspanne(int a);

};


#endif // CABASE_H
