#include "gamewidget.h"
#include <QRect>
#include <QPaintEvent>
#include <QtCore>
#include "cabase.h"
#include <QBrush>
#include <QGraphicsScene>
#include <QGraphicsView>
#include <iostream>
#include <fstream>
#include <QKeyEvent>

using namespace std;

CAbase field(30,30);
SnakeFeld field2(30,30);
HunterandHunted field3(30,30);

GameWidget::GameWidget(QWidget *parent) : QWidget(parent)
{   this->resize(this->height(),this->height()); //grösse der einzelnen zellen
    timer->setInterval(100);
    timer2->setInterval(200); // timer für Snake
    timer3->setInterval(100); // timer für HunterandHunted
    connect(timer, SIGNAL(timeout()), this, SLOT(nextGeneration()));
    connect(timer2,SIGNAL(timeout()), this, SLOT(Bewegung())); // timer für Snake mit Bewegung verbunden
    connect(timer3,SIGNAL(timeout()), this, SLOT(jagen())); //timer für die jäger + gejagten

}

void GameWidget::mousePressEvent(QMouseEvent *e){
    xKor = e->x(); //pixelgrösse
    yKor = e->y();

    xKor = xKor / rectHeight;  //xZellenGrösse bzw Zellenkoordinaten
    yKor = yKor / rectHeight;
    if (spiel == 0)
    {
        if (xKor < field.getNx() && yKor < field.getNy() and xKor > -1 and yKor > -1)
        {
            field.setzelle(xKor,yKor); //
            update();
        }

    }
    if (spiel == 2)
    {
        if(xKor < field3.getNx() && yKor < field3.getNx() and xKor > -1 and yKor > -1)
        {
            switch (zellen)
            {
            case 0:
                field3.setFood(xKor,yKor);
                update();
                break;
            case 1:
                field3.setHunted(xKor,yKor);
                update();
                break;
            case 2:
                field3.setHunter(xKor,yKor);
                update();
                break;
            }
        }
    }
}

void GameWidget::mouseMoveEvent(QMouseEvent *e){
    xKor = e->x();  //gibt x-spielfeldgröesse in pixel an xKor
    yKor = e->y();

    xKor = xKor / rectHeight; //teilt pixel-spielfelgroesse durch kleines quadrat, xKor x für dann kleines quadrat
    yKor = yKor / rectHeight;
    if (spiel == 0)
    {
        if (xKor < field.getNx() && yKor < field.getNy() and xKor > -1 and yKor > -1)
        {
            field.setzelle(xKor,yKor); //
            update();
        }

    }
    if (spiel == 2)
    {
        if(xKor < field3.getNx() && yKor < field3.getNx() and xKor > -1 and yKor > -1)
        {
            switch (zellen)
            {
            case 0:
                field3.setFood(xKor,yKor);
                update();
                break;
            case 1:
                field3.setHunted(xKor,yKor);
                update();
                break;
            case 2:
                field3.setHunter(xKor,yKor);
                update();
                break;
            }
        }
    }
}

void GameWidget::paintEvent(QPaintEvent *event)
{

    this->resize(this->height(),this->height()); //unbenutzt

    rectHeight = this->height() / field.getNx();  //kleines quadrat

    QRect quadrat(0,0,0,0); //erzeuge quadrat
    QBrush colour(Qt::black,Qt::SolidPattern); //Farbe für Rest der Schlange
    QBrush colour2(Qt::blue,Qt::SolidPattern); //Farbe für Schlangenkopf
    QBrush colour3(Qt::green,Qt::SolidPattern); //Farbe für Essen
    QBrush colour4(Qt::red,Qt::SolidPattern); //Farbe für Jäger
    QPainter painter(this);  //Objektinstanz
    painter.setPen(Qt::red); // Gitter

    if(spiel == 0) // Für GameofLife
    {
        for(int x = 0; x<field.getNx(); x++)  //Grid for schleife
    {
        for(int y = 0; y<field.getNy(); y++)
        {
            quadrat.setRect(x*rectHeight,y*rectHeight,rectHeight,rectHeight); // quadrat ruft funktion auf die neue grösse fuer quadrat festsetzt

            if(field.getzelle(x,y) == 1)
                painter.fillRect(quadrat,colour);
            else
                painter.drawRect(quadrat); //falls 0, tot, dann wird nur rechteck gezeichnet

        }
    }
    }
    else if(spiel == 1) // Für Snake
    {
        for(int x = 0; x<field2.returnNx(); x++)  //Grid for schleife
            {
                for(int y = 0; y<field2.returnNy(); y++)
                {
                    quadrat.setRect(x*rectHeight,y*rectHeight,rectHeight,rectHeight); // quadrat ruft funktion auf die neue grösse fuer quadrat festsetzt

                    if(field2.getZelle(x,y) >= 1) // Rest der Schlange wird schwarz gefüllt
                    {painter.fillRect(quadrat,colour);}
                    if(field2.getZelle(x,y) == field2.returnLaenge()) // Kopf(Länge) wird blau gefüllt
                    {painter.fillRect(quadrat,colour2);}
                    if(field2.getZelle(x,y) == -2) // Feld mit Essen wird Grün gefüllt
                    {
                        painter.fillRect(quadrat,colour3);
                    }
                    else
                    {painter.drawRect(quadrat);} //falls 0, tot, dann wird nur rechteck gezeichnet
                }
            }
    }
    else if (spiel == 2)
    {
        for(int x = 0; x < field3.getNx(); x++)
        {
            for(int y = 0; y<field3.getNx(); y++)
            {
                quadrat.setRect(x*rectHeight,y*rectHeight,rectHeight,rectHeight);
                if(field3.getZelle(x,y) == 1)
                {painter.fillRect(quadrat,colour3);}
                if(field3.getZelle(x,y) > 1)
                {painter.fillRect(quadrat,colour4);}
                if(field3.getZelle(x,y) < 0)
                {
                    painter.fillRect(quadrat,colour2);
                }

                else

                {painter.drawRect(quadrat);} //falls 0, tot, dann wird nur rechteck gezeichnet
            }

        }


    }
}

void GameWidget::nextGeneration(){

    field.spieldeslebensmitnelementN();
    update();
}



void GameWidget::setTimerIntervall(int arg1){
    timer->setInterval(arg1);
    timer3->setInterval(arg1);
    update();

}

void GameWidget::startGame(){
    if(spiel == 0) // Timer für GameofLife gestartet
    {timer->start();}
    else if( spiel == 1)
    {
        timer2->start(); // Timer für SNake gestartet
    }
    else if(spiel == 2)
    {
        timer3->start();
    }
}
void GameWidget::stopGame(){
    timer->stop(); // Stop egal welches Spiel
    timer2->stop();
    timer3->stop();
}

void GameWidget::clearBoard(){
    if (spiel == 0) // GameofLife
    {
        field.setNx(field.getNx());
        update();
    }
    if (spiel == 1) // Snake
    {
        field2.resetspiel(); // Feld reseted
        field2.setZelle(5,27); // Kopf gesetzt
        field2.Bewegung(56); // Kopf zweimal nach oben bewegt sodass Schlangenkörper entsteht
        field2.Bewegung(56);
        field2.essen(); // Essen gesetzt
        update();
    }
    if (spiel == 2)
    {
        field3.setNx(field3.getNx());
        update();
    }
}

void GameWidget::UniversumGroesse(int a){
    if (spiel == 0) // GameofLife Feldgröße wird geändert
    {
        field.setNx(a);
        field.setNy(a);
        update();
    }
    if (spiel == 1) // Snake keine Änderung
        update();
    if (spiel == 2)
    {
        field3.setNx(a);
        update();
    }
}

void GameWidget::Savefield(){
    std::ofstream datafile("savefile.txt");
    if (datafile.is_open())
    {
        datafile << field.getNx() << "\n";
        datafile << field.getNx() << "\n";
        for(int i = 0; i < field.getNx(); i++)
        {
            for(int j = 0; j < field.getNy(); j++){
                datafile << field.getzelle(i,j) << "\n";}
    }
        datafile.close();
    }
    update();
}

void GameWidget::Loadfield(){
    std::ifstream datafile("savefile.txt");
    if (datafile.is_open())
    {
        int a,b = 0;
        datafile >> a;
        datafile >> b;
        field.setNx(a);
        field.setNy(b);
        update();
        for(int i = 0; i < field.getNx(); i++)
        {
            for(int j = 0; j < field.getNy(); j++){
                datafile >> field.altesarray[i][j]; }}
        datafile.close();
        update();}
}

void GameWidget::Bewegung(int a) // Evolutionsfunktion bzw. Bewegung
{
    if(timer2->isActive()) // Falls Timer gestartet also Spiel gestartet
    {
        field2.Bewegung(a); // Bewegungsfunktion mit Tastatureingabe als Übergabe
        update();
    }
}

void GameWidget::preparefieldsnake(string a) // String aus Checkbox übergeben
{

    if( a == "Spiel des Lebens") // GameofLife
    {
        spiel = 0; // um zwischen Spielen zu unterscheiden
        clearBoard(); // Feld geleert und neues vorbereitet
    }
    if ( a == "Snake") // Snake
    {
        spiel = 1;
        clearBoard();
    }
    if( a == "Predator Modus")
    {
        spiel = 2;
        clearBoard();
    }
}

void GameWidget::jagen()
{
    field3.WorldEvolutionLifePredator();
    update();
}

void GameWidget::Zellen(string a)
{
    if (a == "Gras / Normal")
    {
        zellen = 0;
        update();
    }

    else if(a == "Gejagter")
    {
        zellen = 1;
        update();
    }

    else if(a == "Jäger")
    {
        zellen = 2;
        update();
    }
}

void GameWidget::Lebenszeit(int a)
{
    field3.setLebensspanne(a);
}
